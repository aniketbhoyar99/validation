import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
const Registration = () => {
    const submitHandler=()=>{

    }
    return (
        <div className="">
    <div className="card container rounded-lg mt-100">

      <h1 className="" style={{ marginLeft: "10px" }}>Registration page</h1>

      <form className="was-validated container mt-20" onSubmit={submitHandler} >
        <div className="form-group mr-sm-20000">
          <label htmlFor="username">Name</label>
          <input type="text" name="username" id="username" style={{height:"50px"}} className="form-control" maxLength="30" minLength="4" required />
          <div className="invalid-feedback">
            *please enter your username.        </div>
        </div>
        <div className="form-group">
          <label htmlFor="username">Email ID</label>
          <input type="email" name="email" id="email" style={{height:"50px"}} className="form-control" required minLength="4" maxLength="30" />
          <div className="invalid-feedback">
            *please enter valid email-ID.
        </div>
        </div>
        <div className="form-group">
          <label htmlFor="username">Mobile No.</label>
          <input type="number" name="MobileNo" id="MobileNo" style={{height:"50px"}} className="form-control" required minLength="4" maxLength='5' />
          <div className="invalid-feedback">
            *please enter valid Mobile No.
        </div>
        </div>
        <div className="form-group">
          <label htmlFor="password">password</label>
          <input type="password" name="password" id="password" style={{height:"50px"}} className="form-control" required maxLength="20" minLength="4" />
          <div className="invalid-feedback">
            *please enter valid password
        </div>


        </div>

      </form>

      <button type="submit" className="container btn-btn primary" style={{width:"1100px",height:"50px",backgroundColor:"#00BFFE"}}>Register</button>


    </div>
    </div>

    )
}

export default Registration;
