import React from 'react'
import Registration from './components/Registration.component';
import AddNewContact from './components/AddNewContact.component'
const App = () => {
  return (
    <div>
          <AddNewContact/>  
  </div>
  )
}

export default App;